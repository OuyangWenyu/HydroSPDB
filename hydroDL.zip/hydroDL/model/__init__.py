from .train import trainModel, testModel
from . import rnn
from . import crit
