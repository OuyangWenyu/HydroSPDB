"""
Define 
"""

class geoObj(object):
    def __init__(self):
        
    

class Dataset(object):
    def __init__(self):
        pass

    def __repr__(self):
        return 'later'


class DatasetRaster(Dataset):
    def __init__(self):
        pass

    def __repr__(self):        
        return 'later'


class DatasetVector(Dataset):
    def __init__(self):
        pass

    def __repr__(self):
        return 'later'
