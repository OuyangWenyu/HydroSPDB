from .master import readMasterFile, writeMasterFile, wrapMaster, train, test
from . import default
from .screen import runTrain