from .stat import statError
from . import plot
